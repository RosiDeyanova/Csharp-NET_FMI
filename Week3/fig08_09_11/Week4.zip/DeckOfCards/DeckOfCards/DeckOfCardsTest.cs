﻿using System;

public class DeckOfCardsTest
{
   public static void Main( string[] args )
   {
        DeckOfCards deck = new DeckOfCards();
   } 
} 


