﻿namespace Calculator
{
    enum Operations
    {
        PLUS = 1,
        MINUS = 2,
        MULTIPLY = 3,
        DIV = 4,
        EQUALS = 5
    }
}
