﻿using System;

namespace AccountManagement
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Account account = new Account();
            Console.WriteLine(account);
        }
    }
}
